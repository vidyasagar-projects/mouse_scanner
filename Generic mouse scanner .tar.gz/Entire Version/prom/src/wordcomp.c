#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int strbeg(char *s,char *d)
{
	int i;
	for(i=0;d[i]!='\0';i++)
	{
		if(d[i]!=s[i])
			return 0;
	}
	return 1;
}
int main()
{
	FILE *f;
	char buf[20],*w,*s;
	char *name="JA";
	int len=0,cn=0;;
	f=fopen("word.txt","r");
	while (fgets(buf, sizeof(buf), f)&&cn<5) 
	{
		len = strlen(buf) - 1;
		buf[len] = '\0';
		w = strdup(buf);
		s=strstr(w,name);
		if(s==w)
		{
			printf("%s\n",w);
			cn++;
		}
	}
	return 0;
}
