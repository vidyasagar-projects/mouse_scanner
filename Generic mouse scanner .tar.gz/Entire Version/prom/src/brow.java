import java.io.*;
class brow
{
public static void main(String args[])
{
System.out.println("brow java");
}
}
