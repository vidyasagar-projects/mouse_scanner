#include <stdio.h>
#include <stdlib.h>
main(int argc,char *argv[])
{
execlp("espeak","espeak",argv[1],(char *)0);
return 0;
}
