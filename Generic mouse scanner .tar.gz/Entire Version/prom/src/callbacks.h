#include <gtk/gtk.h>


void
on_window1_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_window1_key_press_event             (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

gboolean
on_window1_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_window2_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_window2_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_window6_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_window7_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_window7_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_window9_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_window9_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_window11_set_focus                  (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_window11_key_release_event          (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

void
on_button88_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button87_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button86_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button85_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button84_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button83_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button82_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button81_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button80_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button79_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button78_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button77_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button76_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button75_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button56_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button55_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button54_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button53_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button52_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button51_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button50_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button49_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button48_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button74_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button73_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button72_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button71_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button70_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button69_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button68_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button67_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button66_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button47_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button46_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button45_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button44_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button43_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button42_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button41_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button40_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button39_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button59_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button58_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button57_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button65_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button64_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button63_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button62_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button61_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button60_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button38_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button37_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button36_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button35_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button34_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button33_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button94_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button93_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button92_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button91_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button90_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button111_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button110_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button121_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button120_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button119_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button118_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button117_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button128_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button133_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button132_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button131_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button130_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button129_released                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button96_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button95_released                   (GtkButton       *button,
                                        gpointer         user_data);
