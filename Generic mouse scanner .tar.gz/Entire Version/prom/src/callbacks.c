#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <pthread.h>
#include <ctype.h>
#include <X11/Xmu/WinUtil.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
//GtkWidget *winclose,*winshow;

extern int windtype;
extern int wordflag;
extern guint scangame(gpointer);
extern guint scansmall(gpointer);
extern guint scanfirst(gpointer);
extern int gameindex;
extern int smallindex;
extern int mventry;
extern int scanflag;
extern int numofscan;
extern int autolen;
extern char btlabel[20];
extern int apindex;
 extern GtkWidget *window7;
 extern GtkWidget *table48;
 extern GtkWidget *button111;
 extern GtkWidget *button110;
 extern GtkWidget *button96;
 extern GtkWidget *button95;

 extern GtkWidget *window9;
 extern GtkWidget *table50;
 extern GtkWidget *button121;
 extern GtkWidget *button120;
 extern GtkWidget *button119;
 extern GtkWidget *button118;
 extern GtkWidget *button117;
 
 extern GtkWidget *window11;
 extern GtkWidget *table52;
 extern GtkWidget *button133;
 extern GtkWidget *button132;
 extern GtkWidget *button131;
 extern GtkWidget *button130;
 extern GtkWidget *button129;
 extern GtkWidget *button128;
 
 extern GtkWidget *window2;
  extern GtkWidget *table3;
  extern GtkWidget *button4;
  extern GtkWidget *button5;
  extern GtkWidget *button91;
  extern GtkWidget *button90;
  extern GtkWidget *button92;
  extern GtkWidget *button93;
  extern GtkWidget *button94;
   extern guint scanselectapp(gpointer);
  extern KeySym kkk;
  extern guint hideun(gpointer);
  
  extern GtkWidget *entry1;
  extern GtkWidget *window1;
  extern GtkWidget *table1;
  extern GtkWidget *table2;
  extern GtkWidget *viewport1;
  extern GtkWidget *table7;
  extern GtkWidget *viewport12;
  extern GtkWidget *table18;
  extern GtkWidget *button1;
  extern GtkWidget *button2;
  extern GtkWidget *button3;
  extern GtkWidget *viewport13;
  extern GtkWidget *table20;
  extern GtkWidget *button6;
  extern GtkWidget *button7;
  extern GtkWidget *button8;
  extern GtkWidget *viewport14;
  extern GtkWidget *table21;
  extern GtkWidget *button9;
  extern GtkWidget *button10;
  extern GtkWidget *button11;
  extern GtkWidget *viewport6;
  extern GtkWidget *table11;
  extern GtkWidget *viewport28;
  extern GtkWidget *table28;
  extern GtkWidget *button30;
  extern GtkWidget *button31;
  extern GtkWidget *button32;
  extern GtkWidget *viewport29;
  extern GtkWidget *table29;
  extern GtkWidget *button33;
  extern GtkWidget *button34;
  extern GtkWidget *button35;
  extern GtkWidget *viewport30;
  extern GtkWidget *table30;
  extern GtkWidget *button36;
  extern GtkWidget *button37;
  extern GtkWidget *button38;
  extern GtkWidget *viewport9;
  extern GtkWidget *table14;
  extern GtkWidget *viewport38;
  extern GtkWidget *table38;
  extern GtkWidget *button60;
  extern GtkWidget *button61;
  extern GtkWidget *button62;
  extern GtkWidget *viewport39;
  extern GtkWidget *table39;
  extern GtkWidget *button63;
  extern GtkWidget *button64;
  extern GtkWidget *button65;
  extern GtkWidget *viewport37;
  extern GtkWidget *table37;
  extern GtkWidget *button57;
  extern GtkWidget *button58;
  extern GtkWidget *button59;
  extern GtkWidget *table4;
  extern GtkWidget *viewport3;
  extern GtkWidget *table9;
  extern   GtkWidget *viewport16;
  extern GtkWidget *table22;
  extern GtkWidget *button12;
  extern GtkWidget *button13;
  extern GtkWidget *button14;
  extern GtkWidget *viewport17;
  extern GtkWidget *table23;
  extern GtkWidget *button15;
  extern GtkWidget *button16;
  extern GtkWidget *button17;
  extern GtkWidget *viewport18;
  extern GtkWidget *table24;
  extern GtkWidget *button18;
  extern GtkWidget *button19;
  extern GtkWidget *button20;
  extern GtkWidget *viewport7;
  extern GtkWidget *table12;
  extern GtkWidget *viewport31;
  extern GtkWidget *table31;
  extern GtkWidget *button39;
  extern GtkWidget *button40;
  extern GtkWidget *button41;
  extern GtkWidget *viewport32;
  extern GtkWidget *table32;
  extern GtkWidget *button42;
  extern GtkWidget *button43;
  extern GtkWidget *button44;
  extern GtkWidget *viewport33;
  extern GtkWidget *table33;
  extern GtkWidget *button45;
  extern GtkWidget *button46;
  extern GtkWidget *button47;
  extern GtkWidget *viewport10;
  extern GtkWidget *table15;
  extern GtkWidget *viewport40;
  extern GtkWidget *table40;
  extern GtkWidget *button66;
  extern GtkWidget *button67;
  extern GtkWidget *button68;
  extern GtkWidget *viewport41;
  extern GtkWidget *table41;
  extern GtkWidget *button69;
  extern GtkWidget *button70;
  extern GtkWidget *button71;
  extern GtkWidget *viewport42;
  extern GtkWidget *table42;
  extern GtkWidget *button72;
  extern GtkWidget *button73;
  extern GtkWidget *button74;
  extern GtkWidget *table5;
  extern GtkWidget *viewport4;
  extern GtkWidget *table10;
  extern GtkWidget *viewport19;
  extern GtkWidget *table25;
  extern GtkWidget *button21;
  extern GtkWidget *button22;
  extern GtkWidget *button23;
  extern GtkWidget *viewport20;
  extern GtkWidget *table26;
  extern GtkWidget *button24;
  extern GtkWidget *button25;
  extern GtkWidget *button26;
  extern GtkWidget *viewport21;
  extern GtkWidget *table27;
  extern GtkWidget *button27;
  extern GtkWidget *button28;
  extern GtkWidget *button29;
  extern GtkWidget *viewport8;
  extern GtkWidget *table13;
  extern GtkWidget *viewport34;
  extern GtkWidget *table34;
  extern GtkWidget *button48;
  extern GtkWidget *button49;
  extern GtkWidget *button50;
  extern GtkWidget *viewport35;
  extern GtkWidget *table35;
  extern GtkWidget *button51;
  extern GtkWidget *button52;
  extern GtkWidget *button53;
  extern GtkWidget *viewport36;
  extern GtkWidget *table36;
  extern GtkWidget *button54;
  extern GtkWidget *button55;
  extern GtkWidget *button56;
  extern GtkWidget *viewport11;
  extern GtkWidget *table16;
  extern GtkWidget *viewport43;
  extern GtkWidget *table43;
  extern GtkWidget *button75;
  extern GtkWidget *button76;
  extern GtkWidget *button77;
  extern GtkWidget *viewport44;
  extern GtkWidget *table44;
  extern GtkWidget *button78;
  extern GtkWidget *button79;
  extern GtkWidget *button80;
  extern GtkWidget *viewport45;
  extern  GtkWidget *table45;
  extern GtkWidget *button81;
  extern GtkWidget *button82;
  extern GtkWidget *button83;
  extern GtkWidget *viewport5;
  extern GtkWidget *table17;
  extern GtkWidget *viewport22;
  extern GtkWidget *viewport23;
  extern GtkWidget *button84;
  extern GtkWidget *viewport24;
  extern GtkWidget *button85;
  extern GtkWidget *viewport25;
  extern GtkWidget *button86;
  extern GtkWidget *viewport26;
  extern GtkWidget *button87;
  extern   GtkWidget *viewport27;
  extern  GtkWidget *button88;

 
  extern guint scanmv(gpointer);  
  extern guint scansv(gpointer);  
  extern guint scanbt(gpointer);  
  
  extern int mode,mvindex;
  extern int keypress;
  extern int svindex;
  extern int mvtosv;
  extern int svtobt;
  extern int btindex;
  extern int bttokey;
  extern int v4index;
  extern int caps,alt,shift,ctrl,altgr;
  extern char  key[20];
  int len=0;
  char s[20];
  
  int firstentry=1;
  int firstindex=-1;

//  guint showhide(gpointer data)
// {
// 	static int i;
// 	if(i==0)
// 	{
// 		i=1;
// 		gtk_widget_hide (winclose);
// 		return 1;
// 	}
// 	else
// 	{
// 		i=0;
// 		gtk_widget_show (winshow);
// 		return 0;
// 	}
// 	return 0;
// }
void
on_window1_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
	
	
// 	g_timeout_add(1000,scanmv,NULL);

}


gboolean
on_window1_key_press_event             (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{

  return FALSE;
  
  
}




void strlower(char *k)
{
	int i;
	for(i=0;k[i]!=NULL;i++)
		k[i]=tolower(k[i]);
}
void strupper(char *k)
{
	int i;
	for(i=0;k[i]!=NULL;i++)
		k[i]=toupper(k[i]);
}
int strbeg(char *s,char *d)
{
	int i;
	strlower(s);
	strlower(d);
	for(i=0;d[i]!='\0';i++)
	{
		if(d[i]!=s[i])
			return 0;
	}
	return 1;
}
void wordcomp(char *name)
{
	FILE *f;
	GtkWidget *wordbt[]={button84,button85,button86,button87,button88 };
	char buf[20],*w,*ss;
	int len=0,cnt=0;
	//g_print("wordcomp  %s\n",name);
	f=fopen("word.txt","r");
	while (fgets(buf, sizeof(buf), f)&&cnt<5) 
	{
	len = strlen(buf) - 1;
	buf[len] = '\0';
	w = strdup(buf);
	//g_print("%d\n",strbeg(w,name));
	if(strbeg(w,name))
	{
		//printf("%s\n",w);
		gtk_button_set_label(wordbt[cnt],w);
		cnt++;
	}
	}
}

KeySym charactertokeysym(char i)
{
	KeySym x;
	char subbuf[15];
     
	if(isalpha(i))
	{
		sprintf(subbuf,"%c",i);
		x = XStringToKeysym(subbuf);
		return(x);
	} 
	else if(isdigit(i))
	{
		switch(i){
			case '0': return(XK_0); case '1': return(XK_1); 
			case '2': return(XK_2); case '3': return(XK_3);
			case '4': return(XK_4); case '5': return(XK_5);
			case '6': return(XK_6); case '7': return(XK_7);
			case '8': return(XK_8); case '9': return(XK_9);
			default:  return(XK_0); 
		} 
	} 
     
	switch(i){
		case '>':  return(XK_greater);   
		case '<':  return(XK_less);
		case '/':  return(XK_slash);
		case ' ':  return(XK_space);
		case '=':  return(XK_equal);
		case '+':  return(XK_plus);
		case '!':  return(XK_exclam);
		case '&':  return(XK_ampersand);
		case '(':  return(XK_parenleft);
		case ')':  return(XK_parenright);
		case '"':  return(XK_quotedbl);
		case '-':  return(XK_minus);
		case '*':  return(XK_asterisk);
		case '.':  return(XK_period);
		case '\b': return(XK_BackSpace);
		case '\t': return(XK_Tab);
		case '\n': return(XK_Return);
		default:   return((KeySym)i);
	}


	return((KeySym)i);
} 


char voicestr[20];
guint espeakfun(gpointer data)
{
	if(fork()==0)
	{
			
		execlp("espeak","espeak",voicestr,(char *)NULL);
	}
	else
		return 0;
	
}

int keyflag=0;
extern guint scanfirst(gpointer);
gboolean
on_window1_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
	GtkWidget *sv[11][3]={ {NULL,NULL,NULL},
		{viewport12,viewport13,viewport14},	
  {viewport16,viewport17,viewport18},	
  {viewport19,viewport20,viewport21},	
  {viewport23,viewport24,viewport25},	
  {viewport28,viewport29,viewport30},	
  {viewport31,viewport32,viewport33},	
  {viewport34,viewport35,viewport36},	
  {viewport37,viewport38,viewport39},	
  {viewport40,viewport41,viewport42},	
  {viewport43,viewport44,viewport45},	
	} ;
	GtkWidget *wordbt[]={button84,button85,button86,button87,button88 };
	int i;
	char *oldk;
	KeySym keysym;
	
	char autostr[20];
	GtkWidget* mv[11]={NULL,viewport1,viewport3,viewport4,viewport5,viewport6,viewport7,viewport8,viewport9,viewport10,viewport11};
	GdkColor color1,color2,color3;
	
	GtkWidget *v4[5]={button84,button85,button86,button87,button88};
	GtkWidget *bt[11][3][3];
	
	bt[1][0][0]=button1;bt[1][0][1]=button2;bt[1][0][2]=button3;
	
	bt[1][1][0]=button6;bt[1][1][1]=button7;bt[1][1][2]=button8;
	
	bt[1][2][0]=button9;bt[1][2][1]=button10;bt[1][2][2]=button11;
	
	
	bt[2][0][0]=button12;bt[2][0][1]=button13;bt[2][0][2]=button14;
	
	bt[2][1][0]=button15;bt[2][1][1]=button16;bt[2][1][2]=button17;
	
	bt[2][2][0]=button18;bt[2][2][1]=button19;bt[2][2][2]=button20;
		
	
	bt[3][0][0]=button21;bt[3][0][1]=button22;bt[3][0][2]=button23;
	
	bt[3][1][0]=button24;bt[3][1][1]=button25;bt[3][1][2]=button26;
	
	bt[3][2][0]=button27;bt[3][2][1]=button28;bt[3][2][2]=button29;
	
	
	bt[5][0][0]=button30;bt[5][0][1]=button31;bt[5][0][2]=button32;
	
	bt[5][1][0]=button33;bt[5][1][1]=button34;bt[5][1][2]=button35;
	
	bt[5][2][0]=button36;bt[5][2][1]=button37;bt[5][2][2]=button38;
		
	
	bt[6][0][0]=button39;bt[6][0][1]=button40;bt[6][0][2]=button41;
	
	bt[6][1][0]=button42;bt[6][1][1]=button43;bt[6][1][2]=button44;
	
	bt[6][2][0]=button45;bt[6][2][1]=button46;bt[6][2][2]=button47;
	
	
	bt[7][0][0]=button48;bt[7][0][1]=button49;bt[7][0][2]=button50;
	
	bt[7][1][0]=button51;bt[7][1][1]=button52;bt[7][1][2]=button53;
	
	bt[7][2][0]=button54;bt[7][2][1]=button55;bt[7][2][2]=button56;
		
	
	bt[8][0][0]=button57;bt[8][0][1]=button58;bt[8][0][2]=button59;
	
	bt[8][1][0]=button60;bt[8][1][1]=button61;bt[8][1][2]=button62;
	
	bt[8][2][0]=button63;bt[8][2][1]=button64;bt[8][2][2]=button65;
		
	
	bt[9][0][0]=button66;bt[9][0][1]=button67;bt[9][0][2]=button68;
	
	bt[9][1][0]=button69;bt[9][1][1]=button70;bt[9][1][2]=button71;
	
	bt[9][2][0]=button72;bt[9][2][1]=button73;bt[9][2][2]=button74;
	
		
	
	bt[10][0][0]=button75;bt[10][0][1]=button76;bt[10][0][2]=button77;
	
	bt[10][1][0]=button78;bt[10][1][1]=button79;bt[10][1][2]=button80;
	
	bt[10][2][0]=button81;bt[10][2][1]=button82;bt[10][2][2]=button83;
	
	
	
	
	
	//g_usleep(444444);	
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	gdk_color_parse("green",&color3);
	if(event->keyval==109)
	{
		if(mvindex==0)
			mode=1;
	   if(mode==1)
	   {
		   mvindex=0;
		    g_timeout_add(1000,scanmv,NULL);
	   }
	   else if(mode==2)
	   {
		   keypress=1;
// 		  // while(keypress==1)
// 		   {
// 			   g_usleep(99999);
// 		   }
		   gtk_widget_modify_bg(mv[mvindex],GTK_STATE_NORMAL,&color2);
		   for(i=0;i<3;i++)
		   {
			   gtk_widget_modify_bg(sv[mvindex][i],GTK_STATE_NORMAL,&color2);
		   }
		   if(mvindex==4)
		   {
			   gtk_widget_modify_bg(viewport26,GTK_STATE_NORMAL,&color2);
			   gtk_widget_modify_bg(viewport27,GTK_STATE_NORMAL,&color2);
		   }
		   mvtosv=mvindex;
		   //g_usleep(999999);	
		   g_print("mvindex %d\n",mvindex);
		   //scansv(NULL);
		   svindex=-1;
		   g_timeout_add(1000,scansv,NULL);
		   mvindex=0;
	   }
	   else if(mode==3)
	   {
		   keypress=1;
		   gtk_widget_modify_bg(sv[mvtosv][svindex],GTK_STATE_NORMAL,&color2);
		   svtobt=svindex;
		   g_print("svindex %d\n",svindex);
		   btindex=-1;
		   g_timeout_add(1000,scanbt,NULL);
		   svindex=-1;
		   //mode=1;
	   }
	   else if(mode==4)
	   {
		   keypress=1;
		   gtk_widget_modify_bg(bt[mvtosv][svtobt][btindex],GTK_STATE_NORMAL,&color2);
		   bttokey=btindex;
		   g_print("btindex %d\n",btindex);
		   mvindex=0;
		   strcpy(key,gtk_button_get_label(bt[mvtosv][svtobt][bttokey]));
		   //kkk=XK_5;
		   
		   strlower(key);
		   //key=g_string_ascii_down(key);
		   if(strcmp(key,"cap")==0)
		   {
			   keyflag=0;
		     if(caps==0)
		     {
			     gtk_widget_modify_bg(bt[mvtosv][svtobt][bttokey],GTK_STATE_NORMAL,&color3);	   
		     	caps=1;
		     }
		     else
		     {
			     gtk_widget_modify_bg(bt[mvtosv][svtobt][bttokey],GTK_STATE_NORMAL,&color2);	   
			 caps=0;
		     }
		   }
		   else if(strcmp(key,"shift")==0)
		   {
			   shift=1;
			   gtk_widget_modify_bg(bt[mvtosv][svtobt][bttokey],GTK_STATE_NORMAL,&color3);	   
			   keyflag=1;
		   }
		   else if(strcmp(key,"alt")==0)
		   {
			   alt=1;
			   gtk_widget_modify_bg(bt[mvtosv][svtobt][bttokey],GTK_STATE_NORMAL,&color3);	   
			   keyflag=1;
		   }
		   else if(strcmp(key,"ctrl")==0)
		   {
			   ctrl=1;
			   gtk_widget_modify_bg(bt[mvtosv][svtobt][bttokey],GTK_STATE_NORMAL,&color3);	   
			   keyflag=1;
		   }
		   else if(strcmp(key,"rtclk")==0)
		   {
			   altgr=1;
			   keyflag=0;
		   }
		   else
		   {
			   keyflag=0;
			   
		/*	   if((shift==0&&caps==1)||(shift==1&&caps==0))
				strupper(key);
		*/	  /* shift=0;
			   alt=0;
			   ctrl=0;*/
			   gtk_widget_modify_bg(button41,GTK_STATE_NORMAL,&color2);	   
			   gtk_widget_modify_bg(button43,GTK_STATE_NORMAL,&color2);	   
			   gtk_widget_modify_bg(button44,GTK_STATE_NORMAL,&color2);	   
		   }
		   
		   g_print("%s\n",key);
                   		   
		   oldk=strdup(key);
		   if(oldk[0]=='!'||oldk[0]=='@'||oldk[0]=='#'||oldk[0]=='$'||oldk[0]=='%'||oldk[0]=='^'||oldk[0]=='&'||oldk[0]=='*'||oldk[0]=='('||oldk[0]==')'||oldk[0]=='_'||oldk[0]=='+'||oldk[0]=='?')
			   shift=1;
		      if(strlen(oldk)==1)
		      {
			      strcpy(voicestr,oldk);
			      g_timeout_add(500,espeakfun,NULL);   
			   keysym=charactertokeysym(oldk[0]);
		      }
		   else
		   {
			   strlower(oldk);
			 if(strcmp(oldk,"spc")==0)
				keysym=charactertokeysym(' ');
			 else if(strcmp(oldk,"ent")==0)
			 {
				 len=0;
				 s[len]='\0';
				keysym=charactertokeysym('\n');			   			   
			 }
			 else if(strcmp(oldk,"alt")==0)
				 keysym=XK_Alt_L;
			 else if(strcmp(oldk,"esc")==0)
				 keysym=XK_Escape;
			 else if(strcmp(oldk,"ctrl")==0)
				 keysym= XK_Control_L;
			 else if(strcmp(oldk,"shift")==0)
				 keysym=XK_Shift_L;
			 else if(strcmp(oldk,"cap")==0)
				 keysym=XK_Caps_Lock;
			 else if(strcmp(oldk,"bk<-")==0)
				 keysym=XK_BackSpace;
			 else if(strcmp(oldk,"tab")==0)
				 keysym=charactertokeysym('\t');			   			   
			 else if(strcmp(oldk,"up")==0)
				 keysym=XK_Up;
			 else if(strcmp(oldk,"left")==0)
				 keysym=XK_Left;
			 else if(strcmp(oldk,"down")==0)
				 keysym=XK_Down;
			 else if(strcmp(oldk,"right")==0)
				 keysym=XK_Right;
			 else if(strcmp(oldk,"select\nmode")==0)
			 { gtk_widget_hide (window1);
				    
				    mode=1;
				    window7 = create_window7 ();
				    gtk_widget_show (window7);
				    firstindex=-1;
				    //g_timeout_add(1000,scanfirst,NULL);
				    mode=1;
				    return;
				 
			 }
			 else if(strcmp(oldk,"pgup")==0)
				 keysym=XK_Page_Up;
			 else if(strcmp(oldk,"pgdown")==0)
				 keysym=XK_Page_Down;
			 else if(strcmp(oldk,"back")==0)
			 {
				 if(windtype==1)
				 {
					 gtk_widget_hide (window1);
					 //sleep(4);
					 execlp("java","java","browser",(char *)NULL);
				 }
				 else if(windtype==2)
				 {
					 gtk_widget_hide (window1);
					 //sleep(4);
					 execlp("java","java","mouse",(char *)NULL);
				 }
				 else
				 {
				 gtk_widget_hide (window1);
				// sleep(1);
				
				 mode=1;
				 gtk_widget_destroy (window11);
				 window11 = create_window11 ();
				 gtk_widget_show (window11);
				 smallindex=-1;
				// g_timeout_add(1000,scansmall,NULL);
				 return;
				 }
			 }
			 else if(strcmp(oldk,"del")==0)
				 keysym=XK_Delete;
			 else if(strcmp(oldk,"home")==0)
				 keysym=XK_Home;
			 else if(strcmp(oldk,"end")==0)
				 keysym=XK_End;
			 else if(strcmp(oldk,"__")==0)
				 keysym=charactertokeysym('-');
			 else if(strcmp(oldk,"exit")==0)
				 gtk_main_quit();
			 else 
			 {
				 if(shift==1)
				 {	 	 
				 	if(oldk[0]=='<')
				 		keysym=charactertokeysym(',');
					else if(oldk[0]=='>')
						keysym=charactertokeysym('>');
					else if(oldk[0]=='~')
						keysym=charactertokeysym('~');
					else if(oldk[0]==':')
						keysym=charactertokeysym(':');
					else if(oldk[0]=='"')
						keysym=charactertokeysym('"');
					else if(oldk[0]=='|')
						keysym=charactertokeysym('|');
					else if(oldk[0]=='{')
						keysym=charactertokeysym('{');
					else if(oldk[0]=='}')
						keysym=charactertokeysym('}');
				 }
				 else
				 {
					 if(oldk[0]=='<')
						 keysym=charactertokeysym(',');
					 else if(oldk[0]=='>')
						 keysym=charactertokeysym('.');
					 else if(oldk[0]=='~')
						 keysym=charactertokeysym('`');
					 else if(oldk[0]==':')
						 keysym=charactertokeysym(';');
					 else if(oldk[0]=='"')
						 keysym=charactertokeysym('\'');
					 else if(oldk[0]=='|')
						 keysym=charactertokeysym('\\');
					 else if(oldk[0]=='{')
						 keysym=charactertokeysym('[');
					 else if(oldk[0]=='}')
						 keysym=charactertokeysym(']');
				 }
			 }	 
			 			   			   
		   }
		   
		   kkk=keysym;
		   if(keyflag==0)
		   g_timeout_add(600,hideun,NULL);
		   strlower(key);
		   if(strcmp(key,"spc")==0)
		   {
			   len=0;
		   }
		   else if((strcmp(key,"bk<-")==0)&&len>0)
		   {
					   len--;
					   s[len]='\0';
					   gtk_entry_set_text(entry1,s);
					   for(i=0;i<5;i++)
						   gtk_button_set_label(wordbt[i]," ");
					   if(len!=0)
					   wordcomp(s);		   			
		   }
		   else
		   {
			   //if(key[0]>='a' && key[0]<='z' && strlen(key)==1)
			   if(strlen(key)==1)
			   {
				   s[len++]=key[0];
				   s[len]='\0';
				   gtk_entry_set_text(entry1,s);
				   for(i=0;i<5;i++)
				   gtk_button_set_label(wordbt[i]," ");
				   wordcomp(s);		   			
			   }
		   }
			
		   mvindex=0;		    
		   g_timeout_add(1000,scanmv,NULL);
		   btindex=-1;
		   
	   }
	   else if(mode==5)
	   {
		   keypress=1;
		   gtk_widget_modify_bg(v4[v4index],GTK_STATE_NORMAL,&color2);
		   strcpy(btlabel,gtk_button_get_label(v4[v4index]));
		   bttokey=v4index;
		   g_print("v4index %d\n",v4index);
		   mvindex=0;
		   autolen=strlen(gtk_entry_get_text(entry1));
		   len=0;
		   s[len]='\0';
		   for(i=0;i<5;i++)
			   gtk_button_set_label(wordbt[i]," ");
		   gtk_entry_set_text(entry1," ");
		   g_timeout_add(600,hideun,NULL);
		   mvindex=0;
		   g_timeout_add(1000,scanmv,NULL);
		   strcpy(voicestr,btlabel);
		   g_timeout_add(500,espeakfun,NULL);   
		   v4index=-1;
		   
		   
	   }
	
	}

  return FALSE;
}

void
		on_window2_set_focus                   (GtkWindow       *window,
		GtkWidget       *widget,
  gpointer         user_data)
{
// 	g_timeout_add(1000,scanselectapp,NULL);

}
char aplabel[20];
guint winhide(gpointer data)
{
	static int i;
	if(i==0)
	{
		i=1;
		if(fork()==0)
		{
			
			execlp(aplabel,aplabel, (char *)NULL);
		}
		else
			return 1;
	}
	if(i==1)
	{
		i=2;
		gtk_widget_hide (window2);
		g_timeout_add(2000,winhide,NULL);
		return 0;
	}
	else
	{
		len=0;
		s[len]='\0';
		window1 = create_window1 ();
		gtk_widget_show (window1);
		mvindex=0;
		mode=1;
		//g_timeout_add(1000,scanmv,NULL);
		i=0;
		return 0;
	}
	return 1;
}
int gameselect=0;
guint winhide1(gpointer data)
{
	static int i;
	if(i==0)
	{
		i=1;
		if(fork()==0)
		{
			
			execlp(aplabel,aplabel, (char *)NULL);
		}
		else
			return 1;
	}
	if(i==1)
	{
		i=2;
		gtk_widget_hide (window9);
		g_timeout_add(2000,winhide1,NULL);
		return 0;
	}
	else
	{
		i=0;
		if(gameselect==0)
		{
			len=0;
			s[len]='\0';
			window1 = create_window1 ();
		gtk_widget_show (window1);
		mvindex=0;
		mode=1;
		//g_timeout_add(1000,scanmv,NULL);
		}
		else
		{
			window11 = create_window11 ();
			gtk_widget_show (window11);
			smallindex=-1;
			mode=1;
			//g_timeout_add(1000,scansmall,NULL);
		}
		return 0;
	}
	return 1;
}

gboolean
		on_window2_key_release_event           (GtkWidget       *widget,
		GdkEventKey     *event,
  gpointer         user_data)
{
	char *lbl;
	GtkWidget *sa[]={button4,button5,button90,button91,button92,button93,button94};
	
	if(event->keyval==109)
	{
		if(apindex==-1)
			mode=1;
		if(mode==1)
		{
			apindex=-1;
			g_timeout_add(1000,scanselectapp,NULL);
		}
		else if(mode==2)
		{
			keypress=1;
			strcpy(aplabel,gtk_button_get_label(sa[apindex]));
// 			strcpy(voicestr,aplabel);
// 			g_timeout_add(500,espeakfun,NULL);  
			g_timeout_add(200,winhide,NULL);
		}
	}
	return FALSE;
}

guint scanfirst(gpointer data)
{
	GdkColor color1,color2;
	GtkWidget *fa[]={button111,button110,button95,button96};
// 	if(firstentry==1)
// 	{
// 		firstentry=2;
// 		g_timeout_add(1000,scanfirst,NULL);
// 	}
	mode=2;
	firstindex++;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	if(firstindex!=0)
	{
		gtk_widget_modify_bg(fa[firstindex-1],GTK_STATE_NORMAL,&color2);
	}
	if(keypress==1)
	{
		keypress=0;
		numofscan=2;
		return 0;
	}	
	
	//  g_print("scanfirst\n");
	
	if(firstindex==4)
	{			numofscan--;	
	firstindex=0;
	}
	if(numofscan==0)
	{
		numofscan=2;
		mode=1;
		firstindex=-1;
		return 0;
	}	  
	gtk_widget_modify_bg(fa[firstindex],GTK_STATE_NORMAL,&color1);
	
	return 1;	
}

void 
on_window7_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
	firstindex=-1;
	g_print("window7\n");
	//g_timeout_add(1000,scanfirst,NULL);

}


gboolean
on_window7_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
	char lbl[20];
	GtkWidget *fa[]={button111,button110,button95,button96};
	
	if(event->keyval==109)
	{
		if(firstindex==-1)
			mode=1;
		if(mode==1)
		{
			firstindex=-1;
			g_timeout_add(1000,scanfirst,NULL);
		}
		else if(mode==2)
		{
			keypress=1;
			strcpy(lbl,gtk_button_get_label(fa[firstindex]));
			gtk_widget_hide (window7);
			strlower(lbl);
			firstindex=-1;
			mode=1;
			if(strcmp(lbl,"games")==0)
			{
				
			gtk_widget_show (window9);
			gameindex=-1;
// 			strcpy(voicestr,"games interface");
// 			g_timeout_add(500,espeakfun,NULL);   
			//g_timeout_add(1000,scangame,NULL);
			
			}
			else if(strcmp(lbl,"word processor")==0) 
			{
				
			gtk_widget_show (window2);
			/*strcpy(voicestr,"Word interface");
			g_timeout_add(500,espeakfun,NULL); */ 
			apindex=-1;
			//g_timeout_add(1000,scanselectapp,NULL);
			
			}
			else if(strcmp(lbl,"mouse")==0) 
			{
				//g_print("mouse\n");
				execlp("java","java","mouse",(char *)NULL);
			}
			else if(strcmp(lbl,"browser")==0) 
			{
				//g_print("browser\n");
				if(fork()==0)
				{
				execlp("konqueror","konqueror",(char *)NULL);
				}
				else
				{
					gtk_widget_hide (window7);
				//sleep(4);
				execlp("java","java","browser",(char *)NULL);
				}
			}
				
		}
	}
  return FALSE;
}

int gameentry=1;
int gameindex=-1;

guint scangame(gpointer data)
{
	GdkColor color1,color2;
	GtkWidget *ga[]={button121,button120,button119,button118,button117};
// 	if(gameentry==1)
// 	{
// 		gameentry=2;
// 		g_timeout_add(1000,scangame,NULL);
// 	}
	mode=2;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	
	gameindex++;
	if(gameindex!=0)
	{
		gtk_widget_modify_bg(ga[gameindex-1],GTK_STATE_NORMAL,&color2);
	}
	if(keypress==1)
	{
		mode=1;
		keypress=0;
		numofscan=2;
		return 0;
	}	
	  
	
	if(gameindex==5)
	{			numofscan--;	
	gameindex=0;
	}
	if(numofscan==0)
	{
		numofscan=2;
		mode=1;
		gameindex=-1;
		return 0;
	}	  
	gtk_widget_modify_bg(ga[gameindex],GTK_STATE_NORMAL,&color1);
	
	return 1;	
}

void
on_window9_set_focus                   (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
	gameindex=-1;
	mode=1;
	//g_timeout_add(1000,scangame,NULL);
	

}


gboolean
on_window9_key_release_event           (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
	
	char lbl[20];
	GtkWidget *ga[]={button121,button120,button119,button118,button117};
	
	if(event->keyval==109)
	{
		if(gameindex==-1)
			mode=1;
		//printf("hi1\n");
		if(mode==1)
		{
			//printf("hi2\n");
			gameindex=-1;
			g_timeout_add(1000,scangame,NULL);
		}
		else if(mode==2)
		{//printf("hi3\n");
			keypress=1;
			strcpy(lbl,gtk_button_get_label(ga[gameindex]));
			strlower(lbl);
			if(strcmp(lbl,"hangman")==0)
			{gameselect=0;
				strcpy(aplabel,"khangman");
			}
			else if(strcmp(lbl,"anagram")==0)
			{gameselect=0;
				strcpy(aplabel,"anagramarama");
			}
			else if(strcmp(lbl,"katomic")==0)
			{gameselect=1;
				strcpy(aplabel,"katomic");
			}
			else if(strcmp(lbl,"color lines")==0)
			{gameselect=1;
				strcpy(aplabel,"klines");
			}
			else if(strcmp(lbl,"puzzle")==0)
			{
				gameselect=1;
				strcpy(aplabel,"ksokoban");
			}
// 			strcpy(voicestr,lbl);
// 			g_timeout_add(500,espeakfun,NULL);  
			g_timeout_add(100,winhide1,NULL);
		}
	}

  return FALSE;
}
int smallentry=1;
int smallindex=-1;

guint scansmall(gpointer data)
{
	GdkColor color1,color2;
	GtkWidget *ga[]={button133,button132,button131,button130,button129,button128};
// 	if(smallentry==1)
// 	{
// 		smallentry=2;
// 		g_timeout_add(1000,scansmall,NULL);
// 	}
	mode=2;
	smallindex++;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	  
	if(smallindex!=0)
	{
		gtk_widget_modify_bg(ga[smallindex-1],GTK_STATE_NORMAL,&color2);
	}
	if(keypress==1)
	{
		keypress=0;
		numofscan=2;
		return 0;
	}	
	
	
	if(smallindex==6)
	{			numofscan--;	
	smallindex=0;
	}
	if(numofscan==0)
	{
		numofscan=2;
		mode=1;
		smallindex=-1;
		return 0;
	}	  
	gtk_widget_modify_bg(ga[smallindex],GTK_STATE_NORMAL,&color1);
	
	return 1;	
}


void
on_window11_set_focus                  (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
	windtype=0;
	smallindex=-1;	
	//g_timeout_add(1000,scansmall,NULL);

}
guint hidegame(gpointer data)
{
	extern GtkWidget *window11;
	static int st_flag;
	if(st_flag==0)
	{
		st_flag=1;
		gtk_widget_hide(window11);
		
	}
	else
	{
		st_flag=0;
// 		if(altflag==1)
// 		{
// 			sleepfun();
// 			altflag=0;
		// 			
// 		}
		gtk_widget_show(window11);
		smallindex=-1;
		mode=1;
		//g_timeout_add(1000,scansmall,NULL);
		return 0;
	}
	
	return 1;
}


gboolean
on_window11_key_release_event          (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
	char lbl[20];
	GtkWidget *ga[]={button133,button132,button131,button130,button129,button128};
	GdkColor color2;
	gdk_color_parse("gray",&color2);
	if(event->keyval==109)
	{
		if(smallindex==-1)
			mode=1;
		if(mode==1)
		{
			smallindex=-1;
			g_timeout_add(1000,scansmall,NULL);
		}
		else if(mode==2)
		{
			keypress=1;
			strcpy(lbl,gtk_button_get_label(ga[smallindex]));
			gtk_widget_modify_bg(ga[smallindex],GTK_STATE_NORMAL,&color2);
			strlower(lbl);
			scanflag=1;
			if(strcmp(lbl,"up")==0)
			{
				kkk=XK_Up;
			}
			else if(strcmp(lbl,"down")==0)
			{
				kkk=XK_Down;
			}
			else if(strcmp(lbl,"right")==0)
			{
				kkk=XK_Right;
			}
			else if(strcmp(lbl,"left")==0)
			{
				kkk=XK_Left;
			}
			else if(strcmp(lbl,"special key")==0)
			{
				if(strcmp(aplabel,"katomic")==0)
				{
					kkk=XK_Tab;
				}
				else if(strcmp(aplabel,"klines")==0)
				{
					kkk=XK_space;
				}
				else
				{
					kkk=XK_Return;
				}
			}
			else if(strcmp(lbl,"keyboard")==0)
			{
				scanflag=0;
				gtk_widget_hide (window11);
				mode=1;
				mvindex=0;
				mventry=1;
				len=0;
				s[len]='\0';
				//sleep(1);
				window1 = create_window1 ();
				gtk_widget_show (window1);
				mvindex=0;
				//g_timeout_add(1000,scanmv,NULL);
				mode=1;
			}
			if(scanflag==1)
			{
				g_timeout_add(600,hidegame,NULL);
			//sleep(1);
				smallindex=-1;
				mode=1;
				//g_timeout_add(1000,scansmall,NULL);
				
			}
			/*strcpy(voicestr,lbl);
			g_timeout_add(500,espeakfun,NULL); */ 
			
		}
	}

  return FALSE;
}
void mouseauto(GtkButton *button)
{
//char btlabel[20];
int i;
scanflag=1;
GtkWidget *wordbt[]={button84,button85,button86,button87,button88 };
 strcpy(btlabel,gtk_button_get_label(button));
 autolen=strlen(gtk_entry_get_text(entry1));
 len=0;
 s[len]='\0';
 for(i=0;i<5;i++)
	 gtk_button_set_label(wordbt[i]," ");
 gtk_entry_set_text(entry1," ");
 wordflag=1;
 g_timeout_add(600,hideun,NULL);
 strcpy(voicestr,btlabel);
 g_timeout_add(500,espeakfun,NULL);
 

}
void mousekey(GtkButton *button)
{

int i;
	GtkWidget *wordbt[]={button84,button85,button86,button87,button88 };
	scanflag=1;
	strcpy(voicestr,gtk_button_get_label(button));
	strlower(voicestr);
	g_timeout_add(500,espeakfun,NULL);
	if(voicestr[0]=='<')
		kkk=charactertokeysym(',');
	else   
		kkk=charactertokeysym(voicestr[0]);
	g_timeout_add(600,hideun,NULL);
	s[len++]=voicestr[0];
	s[len]='\0';
	gtk_entry_set_text(entry1,s);
	for(i=0;i<5;i++)
		gtk_button_set_label(wordbt[i]," ");
	wordcomp(s);	
}
void
on_button88_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mouseauto(button);
}


void
on_button87_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mouseauto(button);
}


void
on_button86_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mouseauto(button);
}


void
on_button85_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mouseauto(button);
}


void
on_button84_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
mouseauto(button);
}


void
on_button83_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button82_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button81_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button80_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button79_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button78_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button77_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button76_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button75_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button56_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Right;
	g_timeout_add(600,hideun,NULL);
}


void
on_button55_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Down;
	g_timeout_add(600,hideun,NULL);
}


void
on_button54_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Left;
	g_timeout_add(600,hideun,NULL);

}


void
on_button53_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	if(windtype==1)
	{
		gtk_widget_hide (window1);
		//sleep(4);
		execlp("java","java","browser",(char *)NULL);
	}
	else if(windtype==2)
	{
		gtk_widget_hide (window1);
		//sleep(4);
		execlp("java","java","mouse",(char *)NULL);
	}
	else
	{
	gtk_widget_hide (window1);
	mode=1;
	window11 = create_window11 ();
	gtk_widget_show (window11);
	smallindex=-1;
	//g_timeout_add(1000,scansmall,NULL);
	mode=1;
	}
}


void
on_button52_released                   (GtkButton       *button,
                                        gpointer         user_data)
{

	scanflag=1;
	kkk=XK_Up;
	g_timeout_add(600,hideun,NULL);
}


void
on_button51_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button50_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button49_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button48_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button29_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=charactertokeysym(' ');
	g_timeout_add(600,hideun,NULL);
	len=0;
	s[len]='\0';
}


void
on_button28_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button27_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button26_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button25_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button24_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button23_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button22_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button21_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button74_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);

}


void
on_button73_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);

}


void
on_button72_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);

}


void
on_button71_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_End;
	g_timeout_add(600,hideun,NULL);

}


void
on_button70_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Home;
	g_timeout_add(600,hideun,NULL);

}


void
on_button69_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Delete;
	g_timeout_add(600,hideun,NULL);

}


void
on_button68_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_widget_hide (window1);
	mode=1;
	gtk_widget_show (window7);
	firstindex=-1;
	mode=1;
	//g_timeout_add(1000,scanfirst,NULL);

}


void
on_button67_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Page_Down;
	g_timeout_add(600,hideun,NULL);

}


void
on_button66_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Page_Up;
	g_timeout_add(600,hideun,NULL);

}


void
on_button47_released                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *wordbt[]={button84,button85,button86,button87,button88 };
int i;
	scanflag=1;
	kkk=XK_BackSpace;
	g_timeout_add(600,hideun,NULL);
	if(len>0)
	{
	len--;
	s[len]='\0';
	gtk_entry_set_text(entry1,s);
	for(i=0;i<5;i++)
		gtk_button_set_label(wordbt[i]," ");
	if(len!=0)
		wordcomp(s);
	}
}


void
on_button46_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=charactertokeysym('\t');
	g_timeout_add(600,hideun,NULL);
}


void
on_button45_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GdkColor color1,color2,color3;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	gdk_color_parse("green",&color3);
	 if(caps==0)
{
	gtk_widget_modify_bg(button,GTK_STATE_NORMAL,&color3);	   
	caps=1;
}
		     else
{
	gtk_widget_modify_bg(button,GTK_STATE_NORMAL,&color2);	   
	caps=0;
}
	
	scanflag=1;
	kkk=XK_Caps_Lock;
	g_timeout_add(600,hideun,NULL);
	
}


void
on_button44_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GdkColor color1,color2,color3;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	gdk_color_parse("green",&color3);
	gtk_widget_modify_bg(button,GTK_STATE_NORMAL,&color3);	
	shift=1;

}


void
on_button43_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GdkColor color1,color2,color3;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	gdk_color_parse("green",&color3);
	gtk_widget_modify_bg(button,GTK_STATE_NORMAL,&color3);	
ctrl=1;
}


void
on_button42_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Escape;
	g_timeout_add(600,hideun,NULL);

}


void
on_button41_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GdkColor color1,color2,color3;
	gdk_color_parse("red",&color1);
	gdk_color_parse("gray",&color2);
	gdk_color_parse("green",&color3);
	gtk_widget_modify_bg(button,GTK_STATE_NORMAL,&color3);	
alt=1;
}


void
on_button40_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=charactertokeysym('\n');
	g_timeout_add(600,hideun,NULL);
	len=0;
	s[len]='\0';
}


void
on_button39_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button20_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button19_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button18_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button17_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button16_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button15_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button14_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button13_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button12_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button59_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button58_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button57_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button65_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	
	mousekey(button);
}


void
on_button64_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	
	mousekey(button);
}


void
on_button63_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button62_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button61_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	
	mousekey(button);
}


void
on_button60_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	shift=1;
	mousekey(button);
}


void
on_button38_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button37_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button36_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button35_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button34_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button33_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button32_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button31_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button30_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button11_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button10_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button9_released                    (GtkButton       *button,
                                        gpointer         user_data)
{mousekey(button);

}


void
on_button8_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button7_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button6_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button3_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button2_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);
}


void
on_button1_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	mousekey(button);

}


void
on_button94_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button93_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button92_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button91_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button90_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button5_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);
}


void
on_button4_released                    (GtkButton       *button,
                                        gpointer         user_data)
{
	
	strcpy(aplabel,gtk_button_get_label(button));
	g_timeout_add(200,winhide,NULL);

}


void
on_button111_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_widget_hide (window7);
	gtk_widget_show (window2);
	apindex=-1;
	//g_timeout_add(1000,scanselectapp,NULL);
	mode=1;
}


void
on_button110_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_widget_hide (window7);
	gtk_widget_show (window9);
	gameindex=-1;
	mode=1;
	//g_timeout_add(1000,scangame,NULL);
}


void
on_button121_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gameselect=0;
	strcpy(aplabel,"khangman");
	g_timeout_add(100,winhide1,NULL);
}


void
on_button120_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gameselect=0;
	strcpy(aplabel,"anagramarama");
	g_timeout_add(100,winhide1,NULL);

}


void
on_button119_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gameselect=1;
	strcpy(aplabel,"katomic");
	g_timeout_add(100,winhide1,NULL);

}


void
on_button118_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gameselect=1;
	strcpy(aplabel,"klines");
	g_timeout_add(100,winhide1,NULL);

}


void
on_button117_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	gameselect=1;
	strcpy(aplabel,"ksokoban");
	g_timeout_add(100,winhide1,NULL);

}


void
on_button128_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=0;
	gtk_widget_hide (window11);
	mode=1;
	mvindex=0;
	mventry=1;
	len=0;
	s[len]='\0';//sleep(1);
	window1 = create_window1 ();
	gtk_widget_show (window1);
	mvindex=0;
	mode=1;
	//g_timeout_add(1000,scanmv,NULL);
}


void
on_button133_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Up;
	g_timeout_add(600,hidegame,NULL);
	
}


void
on_button132_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Left;
	g_timeout_add(600,hidegame,NULL);
	
}


void
on_button131_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Down;
	g_timeout_add(600,hidegame,NULL);
	
}


void
on_button130_released                  (GtkButton       *button,
                                        gpointer         user_data)
{
	scanflag=1;
	kkk=XK_Right;
	g_timeout_add(600,hidegame,NULL);
	
}


void
on_button129_released                  (GtkButton       *button,
                                        gpointer         user_data)
{	scanflag=1;

	if(strcmp(aplabel,"katomic")==0)
	{
		kkk=XK_Tab;
	}
	else if(strcmp(aplabel,"klines")==0)
	{
		kkk=XK_space;
	}
	else
	{
		kkk=XK_Return;
	}
	g_timeout_add(600,hidegame,NULL);
}


void
on_button96_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	//g_print("browser\n");
	if(fork()==0)
	{
		execlp("konqueror","konqueror",(char *)NULL);
	}
	else
	{
		gtk_widget_hide (window7);
		sleep(4);
		execlp("java","java","browser",(char *)NULL);
	}
}


void
on_button95_released                   (GtkButton       *button,
                                        gpointer         user_data)
{
	//g_print("mouse\n");
	execlp("java","java","mouse",(char *)NULL);
}

